﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using aula_1b.Database;

namespace aula_1b.Models
{
    internal class EscolaDAO
    {
        private static conexao _conn;

        public EscolaDAO()
        {
            _conn = new conexao();
        }

        public void Insert(Escola escola)
        {
            try
            {
                var comando = _conn.;
            } catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
