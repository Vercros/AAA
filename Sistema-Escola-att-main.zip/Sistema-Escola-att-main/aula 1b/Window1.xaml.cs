﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MySql.Data.MySqlClient;
using aula_1b.Models;

namespace aula_1b
{
    /// <summary>
    /// Lógica interna para Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {

        private Escola _escola = new Escola();

        public Window1()
        {
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _escola.NomeFantasia = txtNomeFantasia.Text
            // = txtNomeFantasia.Text;

            string nomeFantasia = txtNomeFantasia.Text;
            string nome = textNome.Text;
            string cnpj = txtCnpj.Text;
            string inscEst = txtInscEst.Text;
            string tel = txtTel.Text;
            string email = txtEmail.Text;
            string rua = txtRua.Text;
            string num = txtNum.Text;
            string bairro = txtBairro.Text;
            string cidade = txtCidade.Text;
            string cep = txtCep.Text;
            var estado = cbEst.Text;
            string nomeresp = txtNomeRes.Text;
            string telresp = txtTelResp.Text;
            string tipo = "Privada";

            if ((bool)rbPubli.IsChecked)
                tipo = "Pública";

            var data_criacao = dtCriacao.SelectedDate?.ToString("yyyy-MM-dd");

            var conexao = new MySqlConnection("server=localhost;database=bd_escola;port=3360;user=root;password=root");


            try
            {
                conexao.Open();

                var comando = conexao.CreateCommand();

                comando.CommandText = "INSERT INTO Escola (nome_fantasia_esc, razao_social_esc, cnpj_esc, insc_estadul_esc, tipo_esc, data_criacao_esc, " +
                    "responsavel_esc, responsavel_telefone_esc, email_esc, telefone_esc, rua_esc, numero_esc, bairro_esc, cep_esc, cidade_esc, estado_esc) " +
                    "VALUES (@nomefantasia, @razaosocial, @cnpj, @inscestadual, @tipo, @datacriacao, @resp, @resptel, @email, @escolatel, @rua, " +
                    "@endereconr, @bairro, @cep, @cidade, @estado);";

                comando.Parameters.AddWithValue("@nomefantasia", nome);
                comando.Parameters.AddWithValue("@razaosocial", nomeFantasia);
                comando.Parameters.AddWithValue("@cnpj", cnpj);
                comando.Parameters.AddWithValue("@inscestadual", inscEst);
                comando.Parameters.AddWithValue("@tipo", tipo);
                comando.Parameters.AddWithValue("@datacriacao", data_criacao);
                comando.Parameters.AddWithValue("@resp", nomeresp);
                comando.Parameters.AddWithValue("@resptel", telresp);
                comando.Parameters.AddWithValue("@email", email);
                comando.Parameters.AddWithValue("@escolatel", tel);
                comando.Parameters.AddWithValue("@rua", rua);
                comando.Parameters.AddWithValue("@endereconr", num);
                comando.Parameters.AddWithValue("@bairro", bairro);
                comando.Parameters.AddWithValue("@cep", cep);
                comando.Parameters.AddWithValue("@cidade", cidade);
                comando.Parameters.AddWithValue("@estado", estado);

                var resultado = comando.ExecuteNonQuery();

                if (resultado > 0)
                    MessageBox.Show("Registro salvo com sucesso");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
